export function Footer() {
  return (
    <footer className="text-center text-xs text-muted-foreground py-4 border-t shrink-0">
      GraphSim — Built with Firebase and Google AI.
    </footer>
  );
}
